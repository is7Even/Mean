var express = require('express');
var router = express.Router();

var monk = require('monk');
var db = monk('localhost:27017/test');

router.get('/', function (req,res){
	res.render('login');
});
router.post('/', function (req,res){
	console.log(req.body);
});
module.exports = router;