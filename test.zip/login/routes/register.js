var express = require('express');
var router = express.Router();

var monk = require('monk');
var db = monk('localhost:27017/test');

var dunmmyDb = [
	{username:'name1',password:'123456'},
	{username:'name2',password:'asdf'},
	{username:'name3',password:'zxcv'},
];

router.get('/', function (req,res){
	res.render('register');
});
router.post('/', function(req, res) {
    var collection = db.get('users');
    console.log("collection.username");
    collection.find({}, function(err, users){
        if (err) throw err;
		for(var i =0;i<db.length;i++){
			if(allusers[i].username == username){
				res.render('register',{error:"user existed"});
				return;
			}
		}
	});
	res.render('register',{success:"Registration success"})
});
module.exports = router;